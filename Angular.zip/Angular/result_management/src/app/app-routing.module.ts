import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AddStudentsComponent} from './components/add-students/add-students.component'
import {EditStudentComponent} from './components/edit-student/edit-student.component'
import {ListStudentComponent} from './components/list-student/list-student.component'
import {LoginStudentComponent} from './components/login-student/login-student.component'
import {RegistrationStudentComponent} from './components/registration-student/registration-student.component'
import {MainComponent} from './components/main/main.component'
import {SearchComponent} from './components/search/search.component'

const routes: Routes = [
  {path:'',redirectTo:'main',pathMatch:'full'},
  {
    path:'add',
    component:AddStudentsComponent
  },
  {
    path:'search',
    component:SearchComponent
  },
  {
    path:'main',
    component:MainComponent
  },
  {
    path:'edit/:id',
    component:EditStudentComponent
  },
  {
    path:'list',
    component:ListStudentComponent
  },
  {
    path:'login',
    component:LoginStudentComponent
  },
  {
    path:'registration',
    component:RegistrationStudentComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
