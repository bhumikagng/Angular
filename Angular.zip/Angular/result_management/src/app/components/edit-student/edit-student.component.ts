import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms'
import {StudentsService} from '../../students.service'
import {ActivatedRoute} from '@angular/router'

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit {

  constructor(private student:StudentsService,private router:ActivatedRoute) { }

  editStudent=new FormGroup({
    rollno: new FormControl( '' ),
    name: new FormControl( '' ),
    score: new FormControl( '' ),
    dob: new FormControl( '' )
});
  message:boolean=false;
  ngOnInit(): void {
    // console.log(this.router.snapshot.params['id']);
    this.student.getStudentById(this.router.snapshot.params['id']).subscribe((result:any)=>{
      // console.log(result);
      this.editStudent=new FormGroup({
        rollno: new FormControl( result['rollno'] ),
        name: new FormControl( result['name'] ),
        score: new FormControl( result['score'] ),
        dob: new FormControl( result['dob'] )
    });
    });
  }
  UpdateData(){
    // console.log(this.editStudent.value)
    this.student.updateStudentData(this.router.snapshot.params['id'],this.editStudent.value).
    subscribe((result)=>{
      // console.log(result);
      this.message=true;
    })
  }

removeMessage(){
  this.message=false;
}
}
