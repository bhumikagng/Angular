import { Component, OnInit , VERSION, ViewChild,ElementRef} from '@angular/core';
import { StudentsService } from 'src/app/students.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  name = "Angular " + VERSION.major;

  @ViewChild("myNameElem")
  myNameElem!: ElementRef;
  id: any;

  getValue() {
    console.log(this.myNameElem.nativeElement.value);
  }

  resetValue() {
    this.myNameElem.nativeElement.value = "";
  }

  constructor( private student : StudentsService) { }

  ngOnInit(): void {
    // this.id = this.myNameElem.nativeElement.value;
    // this.getOne();
  }

  // getOne() {
  //   this.student.getOne(id).subscribe(data=>{
  //     console.log(data);
  //   })
  // }

}
