import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms'
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration-student',
  templateUrl: './registration-student.component.html',
  styleUrls: ['./registration-student.component.css']
})
export class RegistrationStudentComponent implements OnInit {


  public signupForm !: FormGroup;
  constructor(private formBuilder : FormBuilder, private http : HttpClient ,private router:Router) { }

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      fullname:[''],
      email:[''],
      password:[''],
      mobile:['']
    })
  }
  signUP(){
    this.http.post<any>("http://localhost:3000/signupusers",this.signupForm.value)
    .subscribe(res=>{
      alert("signUP successfull");
      this.signupForm.reset();
      this.router.navigate(['login']);
    },err=>{
      alert("someting went wrong");
    })
  }
}
